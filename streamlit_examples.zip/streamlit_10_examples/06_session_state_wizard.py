import streamlit as st

st.set_page_config(page_title="Wizard", layout="centered")
st.title("Session State: Multi-step Wizard")

if "step" not in st.session_state:
    st.session_state.step = 1
if "answers" not in st.session_state:
    st.session_state.answers = {}

def next_step():
    st.session_state.step += 1

def prev_step():
    st.session_state.step -= 1

step = st.session_state.step

if step == 1:
    st.write("### Step 1: Basic Info")
    st.session_state.answers["name"] = st.text_input(
        "Name",
        st.session_state.answers.get("name", "")
    )
    st.button("Next", on_click=next_step)

elif step == 2:
    st.write("### Step 2: Preferences")
    st.session_state.answers["topic"] = st.selectbox(
        "Favorite topic",
        ["Python", "Data Science", "GenAI", "DevOps"]
    )
    c1, c2 = st.columns(2)
    with c1:
        st.button("Back", on_click=prev_step)
    with c2:
        st.button("Next", on_click=next_step)

else:
    st.write("### Step 3: Review")
    st.json(st.session_state.answers)
    c1, c2 = st.columns(2)
    with c1:
        st.button("Back", on_click=prev_step)
    with c2:
        if st.button("Finish"):
            st.success("Saved!")
