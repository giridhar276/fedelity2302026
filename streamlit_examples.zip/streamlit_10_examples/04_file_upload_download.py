import streamlit as st
import pandas as pd

st.set_page_config(page_title="Upload & Download", layout="wide")
st.title("CSV Upload → Preview → Download")

uploaded = st.file_uploader("Upload a CSV", type=["csv"])

if uploaded:
    df = pd.read_csv(uploaded)
    st.write("### Preview")
    st.dataframe(df, use_container_width=True)

    st.write("### Simple Processing: remove duplicates")
    df2 = df.drop_duplicates()

    csv_out = df2.to_csv(index=False).encode("utf-8")
    st.download_button(
        "Download cleaned CSV",
        data=csv_out,
        file_name="cleaned.csv",
        mime="text/csv",
    )
else:
    sample = "name,score\\nA,10\\nB,20\\nB,20\\n"
    st.caption("Try sample CSV:")
    st.code(sample)
