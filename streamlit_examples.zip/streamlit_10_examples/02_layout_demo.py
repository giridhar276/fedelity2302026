import streamlit as st

st.set_page_config(page_title="Layout Demo", layout="wide")
st.title("Layout Demo: Columns, Tabs, Expanders")

with st.container(border=True):
    st.write("This is a container (grouped section).")

col1, col2, col3 = st.columns(3)
with col1:
    st.metric("Sales", "₹ 2.3L", "+8%")
with col2:
    st.metric("Orders", "1,240", "+3%")
with col3:
    st.metric("Returns", "42", "-2%")

tab1, tab2 = st.tabs(["Details", "Notes"])
with tab1:
    st.write("Detailed content here.")
with tab2:
    with st.expander("Click to expand"):
        st.write("Expandable text content.")
