# Streamlit 10 Examples

Run any single-file example:
  streamlit run 01_basic_widgets.py

Multi-page app:
  cd 10_multipage_app
  streamlit run Home.py
