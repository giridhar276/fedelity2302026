import streamlit as st
import pandas as pd
import numpy as np
import time

st.set_page_config(page_title="Caching", layout="wide")
st.title("Caching Demo")

@st.cache_data(show_spinner=False)
def load_data(n=200_000):
    time.sleep(1)  # simulate slow load
    return pd.DataFrame({
        "x": np.random.randn(n),
        "y": np.random.randn(n),
    })

@st.cache_data(show_spinner=False)
def compute_stats(df):
    time.sleep(1)  # simulate expensive work
    return df.describe()

n = st.slider("Rows", 50_000, 300_000, 200_000, step=50_000)

st.write("Loading data...")
df = load_data(n)

st.write("Computing stats...")
stats = compute_stats(df)

st.write("### Stats")
st.dataframe(stats, use_container_width=True)

st.write("### Sample")
st.dataframe(df.head(50), use_container_width=True)
