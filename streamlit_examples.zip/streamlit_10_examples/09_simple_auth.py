import streamlit as st
import hashlib

st.set_page_config(page_title="Simple Auth", layout="centered")
st.title("Simple Authentication (Demo)")

# Demo-only users (store securely in real apps!)
USERS = {
    "admin": {"hash": hashlib.sha256("admin123".encode()).hexdigest(), "role": "Admin"},
    "user": {"hash": hashlib.sha256("user123".encode()).hexdigest(), "role": "User"},
}

def check_login(username, password):
    if username not in USERS:
        return False, None
    h = hashlib.sha256(password.encode()).hexdigest()
    return (h == USERS[username]["hash"]), USERS[username]["role"]

if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
    st.session_state.role = None
    st.session_state.user = None

if not st.session_state.logged_in:
    with st.form("login"):
        u = st.text_input("Username")
        p = st.text_input("Password", type="password")
        ok = st.form_submit_button("Login")

    if ok:
        valid, role = check_login(u, p)
        if valid:
            st.session_state.logged_in = True
            st.session_state.role = role
            st.session_state.user = u
            st.success(f"Welcome {u} ({role})")
            st.rerun()
        else:
            st.error("Invalid credentials")
else:
    st.info(f"Logged in as {st.session_state.user} ({st.session_state.role})")
    if st.session_state.role == "Admin":
        st.write("### Admin Panel")
        st.write("- View logs\n- Manage users\n- Export reports")
    else:
        st.write("### User Dashboard")
        st.write("- View profile\n- View reports")

    if st.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.role = None
        st.session_state.user = None
        st.rerun()
