import streamlit as st
import time
import random

st.set_page_config(page_title="Realtime Updates", layout="centered")
st.title("Realtime Updates: Progress + Live Chart")

placeholder = st.empty()
chart_placeholder = st.empty()

data = []

start = st.button("Start Simulation")
if start:
    prog = st.progress(0)
    for i in range(1, 101):
        time.sleep(0.05)
        val = (data[-1] if data else 50) + random.randint(-3, 3)
        data.append(max(0, min(100, val)))

        with placeholder.container():
            st.write("Current value:", data[-1])

        chart_placeholder.line_chart(data)
        prog.progress(i)

    st.success("Done!")
