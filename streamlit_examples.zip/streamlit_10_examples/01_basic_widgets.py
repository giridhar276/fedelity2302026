import streamlit as st

st.set_page_config(page_title="Basic Widgets", layout="centered")

st.title("Streamlit Basics: Widgets")
st.sidebar.header("Controls")

name = st.sidebar.text_input("Your name", "Giri")
age = st.sidebar.slider("Age", 1, 100, 30)
agree = st.checkbox("I agree to the terms")

st.write("### Output")
st.write("Name:", name)
st.write("Age:", age)
st.write("Agreed:", agree)

if st.button("Say Hi"):
    st.success(f"Hi {name}! 👋")
