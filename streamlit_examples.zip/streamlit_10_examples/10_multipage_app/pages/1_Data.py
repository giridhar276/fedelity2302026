import streamlit as st
import pandas as pd

st.title("Page 1: Data")
uploaded = st.file_uploader("Upload CSV", type=["csv"])
if uploaded:
    df = pd.read_csv(uploaded)
    st.session_state.store["uploaded_rows"] = len(df)
    st.dataframe(df, use_container_width=True)
    st.success(f"Loaded {len(df)} rows")
else:
    st.caption("Upload any CSV to update shared state.")
