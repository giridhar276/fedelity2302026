import streamlit as st

st.title("Page 2: Forms")

with st.form("notes_form"):
    notes = st.text_area("Notes", st.session_state.store.get("notes", ""))
    saved = st.form_submit_button("Save Notes")

if saved:
    st.session_state.store["notes"] = notes
    st.success("Saved into shared state!")

st.json(st.session_state.store)
