import streamlit as st

st.title("Page 3: Analytics")
rows = st.session_state.store.get("uploaded_rows", 0)
notes = st.session_state.store.get("notes", "")

st.metric("Uploaded Rows", rows)
st.write("Notes preview:")
st.write(notes if notes else "(no notes yet)")
