import streamlit as st

st.set_page_config(page_title="Multi-page App", layout="wide")
st.title("Home")
st.write("Use the left sidebar to navigate pages.")

if "store" not in st.session_state:
    st.session_state.store = {"uploaded_rows": 0, "notes": ""}

st.info("Shared state will be available across pages.")
st.json(st.session_state.store)
