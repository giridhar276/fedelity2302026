import streamlit as st

st.set_page_config(page_title="Forms", layout="centered")
st.title("Forms + Validation")

with st.form("profile_form"):
    name = st.text_input("Name")
    email = st.text_input("Email")
    role = st.selectbox("Role", ["Student", "Developer", "Data Scientist", "Trainer"])
    experience = st.number_input("Experience (years)", 0, 40, 1)
    submitted = st.form_submit_button("Submit")

if submitted:
    errors = []
    if not name.strip():
        errors.append("Name is required.")
    if "@" not in email:
        errors.append("Valid email is required (must contain @).")

    if errors:
        for e in errors:
            st.error(e)
    else:
        st.success("Form submitted!")
        st.json({"name": name, "email": email, "role": role, "experience": experience})
