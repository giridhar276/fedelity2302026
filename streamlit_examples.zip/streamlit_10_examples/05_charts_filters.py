import streamlit as st
import pandas as pd
import numpy as np

st.set_page_config(page_title="Charts & Filters", layout="wide")
st.title("Charts + Filters")

np.random.seed(7)
df = pd.DataFrame({
    "day": pd.date_range("2026-01-01", periods=30),
    "sales": np.random.randint(1000, 8000, 30),
    "region": np.random.choice(["North", "South", "East", "West"], 30)
})

regions = st.multiselect(
    "Filter regions",
    df["region"].unique().tolist(),
    default=df["region"].unique().tolist()
)
df_f = df[df["region"].isin(regions)]

st.write("### Data")
st.dataframe(df_f, use_container_width=True)

st.write("### Line Chart (sales over time)")
st.line_chart(df_f.set_index("day")["sales"])

st.write("### Bar Chart (avg sales by region)")
st.bar_chart(df_f.groupby("region")["sales"].mean())
